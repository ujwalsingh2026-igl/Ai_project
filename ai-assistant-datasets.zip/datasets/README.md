# datasets/: how to use

Put this folder at `C:\ai-assistant\datasets` (next to `backend`). Open PowerShell:

```powershell
cd C:\ai-assistant\backend
.\.venv\Scripts\Activate.ps1
cd ..\datasets

python build_seed_dataset.py      # (re)generate data/*.jsonl  (no extra libraries needed)
python validate_dataset.py        # consistency checks -> "OK: dataset is consistent"
python eval_router.py             # how good is the CURRENT regex router?  (uses backend/core)

pip install scikit-learn          # only for the next line
python train_baseline.py          # quick ML baseline on intents_train, reports val/test

pip install datasets              # OPTIONAL, needs internet, NOT TESTED
python download_public.py         # downloads MASSIVE / deepset / xLAM into data/public/ (read licences first)
```

Read in this order: `DATASET_CARD.md` (what and why) -> `SOURCES.md` (public data, verified vs not) -> `eval/BASELINES.md` (measured numbers).

What was actually run when this was built: `build_seed_dataset.py`, `validate_dataset.py`, `eval_router.py`, `train_baseline.py`.
What was NOT run: `download_public.py` (no network in the build sandbox).
